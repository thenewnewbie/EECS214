﻿using System;
using System.Collections.Generic;

namespace Assignment_5
{
    /// <summary>
    /// Implements an undirected graph of "connections" between named people
    /// a la LinkedIn or Facebook.
    /// </summary>
    public class PersonGraph
    {
        /// <summary>
        /// Adds a new person (node) to the graph
        /// </summary>
        /// <param name="name">Name of the person</param>
        public void AddPerson(string name)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Adds a new edge to the graph
        /// </summary>
        /// <param name="person1">Name of first person</param>
        /// <param name="person2">Name of second person</param>
        public void AddConnection(string person1, string person2)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Returns the length of the shortest path between two people in the graph
        /// For example, the distance from a node to itself is 0, from a node to a
        /// neighbor is 1, etc.
        /// </summary>
        /// <param name="person1">Name of the first person</param>
        /// <param name="person2">Name of the second person</param>
        /// <returns>Length of the path</returns>
        public int Distance(string person1, string person2)
        {
            throw new NotImplementedException();
        }
    }
}
