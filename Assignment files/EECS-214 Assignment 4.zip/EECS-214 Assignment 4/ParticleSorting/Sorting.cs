﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParticleSorting
{
    public class Sorting
    {
        private static System.Diagnostics.Stopwatch sortingWatch = new System.Diagnostics.Stopwatch();
        private static long count = 0;
        public static float currentTime, minTime = 9999, maxTime, avgTime;

        public static string getCurrentTime()
        {
            return Sorting.currentTime.ToString("n6") + "ms";
        }

        public static string getMinTime()
        {
            return Sorting.minTime.ToString("n6") + "ms";
        }

        public static string getMaxTime()
        {
            return Sorting.maxTime.ToString("n6") + "ms";
        }

        public static string getAvgTime()
        {
            return Sorting.avgTime.ToString("n6") + "ms";
        }

        public static void DepthSort(Particle[] particles)
        {
            sortingWatch.Restart();

            // You can select which sorting algorithm you'll be using by uncommenting one of the two function calls below
            // You can visually test both of your algorithms this way

            //QuicksortDepthSort(particles);
            InsertionDepthSort(particles);

            sortingWatch.Stop();
            UpdateTimes((float)sortingWatch.ElapsedTicks / System.Diagnostics.Stopwatch.Frequency);
        }

        public static void InsertionDepthSort(Particle[] particles)
        {
            // Implement me
            throw new NotImplementedException();
        }

        public static void QuicksortDepthSort(Particle[] particles)
        {
            // Implement me
            throw new NotImplementedException();
        }

        public static void UpdateTimes(float time)
        {
            time *= 1000;
            count++;
            currentTime = time;
            minTime = minTime < time ? minTime : time;
            maxTime = maxTime > time ? maxTime : time;
            avgTime = avgTime == 0 ? time : ((avgTime * (count - 1)) + time) / count;
        }
    }
}
